#include "raylib.h"
#include <vector>
#include <cstdlib>
#include <ctime>
#include <string>

using namespace std;

enum GameState { MENU, PLAYING, GAME_OVER, GAME_WON };

struct Difficulty {
    string name;
    int rows;
    int cols;
    int mines;
    int cellSize;
};

struct Cell {
    bool isMine = false;
    bool isRevealed = false;
    bool isFlagged = false;
    int neighborMines = 0;
};

// �Ω�D�����s�����c
struct Button {
    Rectangle rect;
    string text;
    Color baseColor;
    Color hoverColor;
};

class Minesweeper {
private:
    vector<vector<Cell>> board;
    Difficulty diff;
    int remainingCells;
    int flaggedCount;
    GameState state;
    bool firstClick;
    double startTime;
    double totalTime;
    int offsetX, offsetY;

    bool isValid(int r, int c) {
        return (r >= 0 && r < diff.rows && c >= 0 && c < diff.cols);
    }

    void generateMines(int startR, int startC) {
        srand(time(0));
        int plantedMines = 0;
        while (plantedMines < diff.mines) {
            int r = rand() % diff.rows;
            int c = rand() % diff.cols;
            if (!board[r][c].isMine && !(r == startR && c == startC)) {
                board[r][c].isMine = true;
                plantedMines++;
            }
        }

        for (int r = 0; r < diff.rows; r++) {
            for (int c = 0; c < diff.cols; c++) {
                if (board[r][c].isMine) continue;
                int count = 0;
                for (int dr = -1; dr <= 1; dr++) {
                    for (int dc = -1; dc <= 1; dc++) {
                        if (isValid(r + dr, c + dc) && board[r + dr][c + dc].isMine) {
                            count++;
                        }
                    }
                }
                board[r][c].neighborMines = count;
            }
        }
    }

public:
    Minesweeper() : state(MENU) {}

    void initGame(Difficulty chosenDiff, int screenWidth, int screenHeight) {
        diff = chosenDiff;
        board.clear();
        board.resize(diff.rows, vector<Cell>(diff.cols));
        remainingCells = diff.rows * diff.cols - diff.mines;
        flaggedCount = 0;
        firstClick = true;
        startTime = GetTime();
        totalTime = 0;
        state = PLAYING;

        offsetX = (screenWidth - (diff.cols * diff.cellSize)) / 2;
        offsetY = (screenHeight - (diff.rows * diff.cellSize)) / 2 - 20;
    }

    void revealCell(int r, int c) {
        if (!isValid(r, c) || board[r][c].isRevealed || board[r][c].isFlagged) return;

        if (firstClick) {
            firstClick = false;
            generateMines(r, c);
            startTime = GetTime();
        }

        board[r][c].isRevealed = true;

        if (board[r][c].isMine) {
            state = GAME_OVER;
            totalTime = GetTime() - startTime;
            return;
        }

        remainingCells--;
        if (remainingCells == 0) {
            state = GAME_WON;
            totalTime = GetTime() - startTime;
            return;
        }

        if (board[r][c].neighborMines == 0) {
            for (int dr = -1; dr <= 1; dr++) {
                for (int dc = -1; dc <= 1; dc++) {
                    revealCell(r + dr, c + dc);
                }
            }
        }
    }

    void checkChording(int r, int c) {
        if (!isValid(r, c) || !board[r][c].isRevealed || board[r][c].neighborMines == 0) return;

        int flagsAround = 0;
        for (int dr = -1; dr <= 1; dr++) {
            for (int dc = -1; dc <= 1; dc++) {
                if (isValid(r + dr, c + dc) && board[r + dr][c + dc].isFlagged) {
                    flagsAround++;
                }
            }
        }

        if (flagsAround == board[r][c].neighborMines) {
            for (int dr = -1; dr <= 1; dr++) {
                for (int dc = -1; dc <= 1; dc++) {
                    if (isValid(r + dr, c + dc) && !board[r + dr][c + dc].isRevealed && !board[r + dr][c + dc].isFlagged) {
                        revealCell(r + dr, c + dc);
                    }
                }
            }
        }
    }

    void toggleFlag(int r, int c) {
        if (isValid(r, c) && !board[r][c].isRevealed) {
            board[r][c].isFlagged = !board[r][c].isFlagged;
            flaggedCount += board[r][c].isFlagged ? 1 : -1;
        }
    }

    void handleInput() {
        if (state != PLAYING) return;

        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) || IsMouseButtonPressed(MOUSE_BUTTON_RIGHT)) {
            Vector2 mousePos = GetMousePosition();
            int c = (mousePos.x - offsetX) / diff.cellSize;
            int r = (mousePos.y - offsetY) / diff.cellSize;

            if (isValid(r, c)) {
                if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                    if (board[r][c].isRevealed) {
                        checkChording(r, c);
                    } else {
                        revealCell(r, c);
                    }
                } else if (IsMouseButtonPressed(MOUSE_BUTTON_RIGHT)) {
                    toggleFlag(r, c);
                }
            }
        }
    }

    void draw() {
        if (state == MENU) return;

        for (int r = 0; r < diff.rows; r++) {
            for (int c = 0; c < diff.cols; c++) {
                int posX = offsetX + c * diff.cellSize;
                int posY = offsetY + r * diff.cellSize;
                Rectangle cellRect = { (float)posX, (float)posY, (float)diff.cellSize - 2, (float)diff.cellSize - 2 };

                if (board[r][c].isRevealed || state == GAME_OVER) {
                    if (board[r][c].isMine) {
                        DrawRectangleRec(cellRect, RED);
                        DrawText("*", posX + diff.cellSize/3, posY + diff.cellSize/4, diff.cellSize/2, BLACK);
                    } else {
                        DrawRectangleRec(cellRect, LIGHTGRAY);
                        if (board[r][c].neighborMines > 0) {
                            string numStr = to_string(board[r][c].neighborMines);
                            Color numColor = BLUE;
                            if (board[r][c].neighborMines == 2) numColor = GREEN;
                            if (board[r][c].neighborMines == 3) numColor = RED;
                            if (board[r][c].neighborMines >= 4) numColor = PURPLE;
                            
                            DrawText(numStr.c_str(), posX + diff.cellSize/3, posY + diff.cellSize/4, diff.cellSize/2, numColor);
                        }
                    }
                } else {
                    DrawRectangleRec(cellRect, GRAY);
                    if (board[r][c].isFlagged) {
                        DrawText("F", posX + diff.cellSize/3, posY + diff.cellSize/4, diff.cellSize/2, ORANGE);
                    }
                }
            }
        }

        int currentTimer = (state == PLAYING) ? (int)(GetTime() - startTime) : (int)totalTime;
        if (firstClick && state == PLAYING) currentTimer = 0;

        string mineText = "Mines: " + to_string(diff.mines - flaggedCount);
        string timeText = "Time: " + to_string(currentTimer) + "s";

        int infoY = offsetY + diff.rows * diff.cellSize + 15;
        DrawText(mineText.c_str(), offsetX, infoY, 22, RED);
        DrawText(timeText.c_str(), offsetX + (diff.cols * diff.cellSize) - 100, infoY, 22, YELLOW);

        if (state == GAME_OVER || state == GAME_WON) {
            DrawRectangle(0, 0, GetScreenWidth(), GetScreenHeight(), Fade(BLACK, 0.6f));
            if (state == GAME_OVER) {
                DrawText("BOOM! GAME OVER!", GetScreenWidth()/2 - 170, GetScreenHeight()/2 - 40, 30, RED);
            } else {
                DrawText("CONGRATULATIONS! YOU WIN!", GetScreenWidth()/2 - 250, GetScreenHeight()/2 - 40, 30, GREEN);
            }
            DrawText("Press [ENTER] to return to Menu", GetScreenWidth()/2 - 160, GetScreenHeight()/2 + 15, 20, WHITE);
        }
    }

    GameState getState() { return state; }
    void setState(GameState s) { state = s; }
};

int main() {
    const int screenWidth = 800;
    const int screenHeight = 600;
    InitWindow(screenWidth, screenHeight, "Raylib Minesweeper Pro");
    SetTargetFPS(60);

    Difficulty difficulties[3] = {
        {"Easy (���)", 9, 9, 10, 45},
        {"Medium (����)", 16, 16, 40, 28},
        {"Hard (����)", 16, 30, 99, 22}
    };

    // ��l�ƤT�����׿����s���ؤo�P��m
    Button buttons[3] = {
        { { (float)screenWidth / 2 - 150, 250, 300, 45 }, "Easy (10 Mines)", DARKGREEN, GREEN },
        { { (float)screenWidth / 2 - 150, 310, 300, 45 }, "Medium (40 Mines)", MAROON, RED },
        { { (float)screenWidth / 2 - 150, 370, 300, 45 }, "Hard (99 Mines)", DARKBLUE, BLUE }
    };

    Minesweeper game;

    while (!WindowShouldClose()) {
        Vector2 mousePos = GetMousePosition();

        if (game.getState() == MENU) {
            // �����ƹ��I�����s
            for (int i = 0; i < 3; i++) {
                if (CheckCollisionPointRec(mousePos, buttons[i].rect)) {
                    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                        game.initGame(difficulties[i], screenWidth, screenHeight);
                    }
                }
            }
        } else if (game.getState() == PLAYING) {
            game.handleInput();
        } else {
            if (IsKeyPressed(KEY_ENTER)) game.setState(MENU);
        }

        BeginDrawing();
        ClearBackground(Color{ 30, 30, 30, 255 }); // �ץ��᪺�ۭq�`��I��

        if (game.getState() == MENU) {
            DrawText("=== MINESWEEPER PRO ===", screenWidth / 2 - 210, 120, 35, GOLD);
            DrawText("Select Difficulty to Start:", screenWidth / 2 - 140, 190, 22, LIGHTGRAY);
            
            // ø�s�ƹ����ʫ��s
            for (int i = 0; i < 3; i++) {
                bool isHovered = CheckCollisionPointRec(mousePos, buttons[i].rect);
                Color btnColor = isHovered ? buttons[i].hoverColor : buttons[i].baseColor;
                
                // �e���s�~�ػP�D��
                DrawRectangleRec(buttons[i].rect, btnColor);
                DrawRectangleLinesEx(buttons[i].rect, 2, WHITE);
                
                // �m��ø�s���s��r
                int textWidth = MeasureText(buttons[i].text.c_str(), 20);
                DrawText(buttons[i].text.c_str(), 
                         buttons[i].rect.x + (buttons[i].rect.width - textWidth) / 2, 
                         buttons[i].rect.y + 12, 20, WHITE);
            }
            
            DrawText("Controls: Left Click = Reveal / Chord | Right Click = Flag", screenWidth / 2 - 260, 490, 18, GRAY);
        } else {
            game.draw();
        }

        EndDrawing();
    }

    CloseWindow();
    return 0;
}
