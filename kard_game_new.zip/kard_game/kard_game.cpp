#include "raylib.h"
#include <vector>
#include <algorithm>
#include <random>
#include <ctime>
#include <string>
#include <fstream>

using namespace std;

const int SCREEN_WIDTH = 750;
const int SCREEN_HEIGHT = 800;

enum GameState { STATE_TITLE, STATE_GAMEPLAY, STATE_END };

struct LevelConfig {
    int rows;
    int cols;
    float timeLimit;
};

const LevelConfig LEVELS[3] = {
    { 4, 4, 60.0f },
    { 4, 6, 90.0f },
    { 6, 6, 120.0f }
};

// �{�N�t��
#define COLOR_BG          GetColor(0x1F232AFF)  
#define COLOR_CARD_BACK   GetColor(0x3B4252FF)  
#define COLOR_CARD_HOVER  GetColor(0x4C566AFF)  
#define COLOR_CARD_FRONT  GetColor(0xECEFF4FF)  
#define COLOR_TEXT_DARK   GetColor(0x2E3440FF)  
#define COLOR_TEXT_LIGHT  GetColor(0xD8DEE9FF)  
#define COLOR_ACCENT      GetColor(0x88C0D0FF)  
#define COLOR_SHADOW      GetColor(0x00000033)  

// --- �S�ġG�ɤl�t�ε��c�� ---
struct Particle {
    Vector2 position;
    Vector2 velocity;
    Color color;
    float alpha;
    float size;
    float lifeTime;
};

struct Card {
    char value;
    bool isRevealed;
    Rectangle rect; 
    float currentSizeScale; 
};

// ���쭵�Ī��� (�K�~���ɮסA�{�����m�X��)
Sound sndClick;
Sound sndMatch;
Sound sndFail;
Sound sndSkill;

// --- ���� 8-bit ���Īi�ΦX���� (�ץ���) ---
Sound GenerateSfx(int type) {
    int sampleRate = 44100;
    int sampleCount = (type == 1) ? sampleRate * 0.25f : (type == 2 ? sampleRate * 0.15f : sampleRate * 0.3f);
    
    // �i�ץ��I�j�G�����ϥμзǪ� malloc �Ӥ��t�O����
    short *data = (short *)malloc(sampleCount * sizeof(short));
    
    for (int i = 0; i < sampleCount; i++) {
        float t = (float)i / (float)sampleRate;
        float frequency = 440.0f;
        float volume = 0.6f;

        float envelope = 1.0f - ((float)i / (float)sampleCount);

        if (type == 1) { // 1. �t�令�\����
            frequency = (t < 0.08f) ? 523.25f : 783.99f; 
            data[i] = (short)(sinf(2.0f * PI * frequency * t) * 32767 * volume * envelope);
        } 
        else if (type == 2) { // 2. �I������
            frequency = 600.0f;
            float wave = (sinf(2.0f * PI * frequency * t) > 0) ? 1.0f : -1.0f;
            data[i] = (short)(wave * 32767 * volume * 0.3f * envelope);
        } 
        else if (type == 3) { // 3. ���ѭ���
            frequency = 300.0f - (t * 400.0f); 
            if (frequency < 100.0f) frequency = 100.0f;
            data[i] = (short)(sinf(2.0f * PI * frequency * t) * 32767 * volume * envelope);
        }
        else { // 4. �ޯ�o�ʭ���
            frequency = 150.0f + (t * 1200.0f);
            float wave = 2.0f * (t * frequency - floorf(0.5f + t * frequency));
            data[i] = (short)(wave * 32767 * volume * 0.4f * envelope);
        }
    }

    Wave wave = { 0 };
    wave.frameCount = sampleCount;
    wave.sampleRate = sampleRate;
    wave.sampleSize = 16;
    wave.channels = 1;
    wave.data = data;

    Sound sound = LoadSoundFromWave(wave);
    
    // �i�ץ��I�j�Graylib ���� Wave ���зǨ禡�O UnloadWave()
    UnloadWave(wave); 
    
    return sound;
}

// �ɤl�Q�o���;�
void TriggerParticles(vector<Particle>& particles, Vector2 center, Color color) {
    for (int i = 0; i < 25; i++) { // �C���z�o 25 ���ɤl
        Particle p;
        p.position = center;
        // �H�����׻P�t��
        float angle = (float)GetRandomValue(0, 360) * DEG2RAD;
        float speed = (float)GetRandomValue(80, 240);
        p.velocity = { cosf(angle) * speed, sinf(angle) * speed };
        p.color = color;
        p.alpha = 1.0f;
        p.size = (float)GetRandomValue(3, 7);
        p.lifeTime = (float)GetRandomValue(40, 80) / 100.0f; // �ͦs 0.4~0.8 ��
        particles.push_back(p);
    }
}

int LoadHighScore() {
    int highScore = 0;
    ifstream file("highscore.txt");
    if (file.is_open()) { file >> highScore; file.close(); }
    return highScore;
}

void SaveHighScore(int score) {
    int currentHigh = LoadHighScore();
    if (score > currentHigh) {
        ofstream file("highscore.txt");
        if (file.is_open()) { file << score; file.close(); }
    }
}

void InitializeLevel(int currentLevel, vector<vector<Card>>& board) {
    int rows = LEVELS[currentLevel].rows;
    int cols = LEVELS[currentLevel].cols;
    int totalCards = rows * cols;
    int pairs = totalCards / 2;
    vector<char> values;
    for (int i = 0; i < pairs; i++) {
        char letter = 'A' + (i % 26); 
        values.push_back(letter);
        values.push_back(letter);
    }

    auto rng = default_random_engine(static_cast<unsigned int>(time(0)));
    shuffle(values.begin(), values.end(), rng);

    int cardSize = (rows == 6 || cols == 6) ? 75 : 95;
    int spacing = (rows == 6 || cols == 6) ? 12 : 18;
    int boardWidth = cols * cardSize + (cols - 1) * spacing;
    int offsetX = (SCREEN_WIDTH - boardWidth) / 2;
    int offsetY = 200; 

    board.assign(rows, vector<Card>(cols));
    int index = 0;
    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            board[r][c].value = values[index++];
            board[r][c].isRevealed = false;
            board[r][c].currentSizeScale = 1.0f;
            board[r][c].rect = {
                (float)(offsetX + c * (cardSize + spacing)),
                (float)(offsetY + r * (cardSize + spacing)),
                (float)cardSize,
                (float)cardSize
            };
        }
    }
}

int main() {
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Cyber Memory Match - Cyberpunk FX Edition");
    
    // --- ���n�G��l�ƭ��T�˸m ---
    InitAudioDevice();

    // �Y�ɦX������ (1:���\, 2:�I��, 3:����, 4:�ޯ�)
    sndMatch = GenerateSfx(1);
    sndClick = GenerateSfx(2);
    sndFail = GenerateSfx(3);
    sndSkill = GenerateSfx(4);

    SetTargetFPS(60);

    GameState currentState = STATE_TITLE;
    int currentLevel = 0; 
    vector<vector<Card>> board;
    InitializeLevel(currentLevel, board);

    // �ɤl�e��
    vector<Particle> particles;

    int firstSelectedR = -1, firstSelectedC = -1;
    int secondSelectedR = -1, secondSelectedC = -1;
    int pairsFound = 0;       
    int score = 0;
    int combo = 0;
    int highScore = LoadHighScore();
    bool isVictory = false; 

    float gameTimer = LEVELS[currentLevel].timeLimit;
    float mismatchTimer = 0.0f;
    bool waitingForMismatch = false;
    int skillsLeft = 2;       
    float skillActiveTimer = 0.0f;
    bool isSkillActive = false;
    float titleTextTimer = 0.0f;

    while (!WindowShouldClose()) {
        Vector2 mousePos = GetMousePosition();
        float dt = GetFrameTime();

        // --- �S�ħ�s�G��s�ɤl���A ---
        for (int i = (int)particles.size() - 1; i >= 0; i--) {
            particles[i].position.x += particles[i].velocity.x * dt;
            particles[i].position.y += particles[i].velocity.y * dt;
            particles[i].lifeTime -= dt;
            particles[i].alpha = particles[i].lifeTime; // �H�۹ةR�ܳz��
            if (particles[i].lifeTime <= 0) {
                particles.erase(particles.begin() + i); // �P���L���ɤl
            }
        }

        switch (currentState) {
            case STATE_TITLE: {
                titleTextTimer += dt;
                Rectangle startBtn = { (float)SCREEN_WIDTH / 2 - 125, 460, 250, 55 };
                bool isHoveringStart = CheckCollisionPointRec(mousePos, startBtn);

                if (IsKeyPressed(KEY_ENTER) || (isHoveringStart && IsMouseButtonPressed(MOUSE_BUTTON_LEFT))) {
                    PlaySound(sndClick); // �����I������
                    currentLevel = 0;
                    InitializeLevel(currentLevel, board);
                    pairsFound = 0; score = 0; combo = 0; skillsLeft = 2;
                    gameTimer = LEVELS[currentLevel].timeLimit;
                    firstSelectedR = firstSelectedC = -1; secondSelectedR = secondSelectedC = -1;
                    isVictory = false;
                    currentState = STATE_GAMEPLAY;
                }
                break;
            }

            case STATE_GAMEPLAY: {
                gameTimer -= dt;
                if (gameTimer <= 0) {
                    gameTimer = 0;
                    SaveHighScore(score);
                    currentState = STATE_END; 
                }

                if (isSkillActive) {
                    skillActiveTimer -= dt;
                    if (skillActiveTimer <= 0) isSkillActive = false;
                }

                // �ϥιD��
                if (IsKeyPressed(KEY_SPACE) && !isSkillActive && !waitingForMismatch && skillsLeft > 0) {
                    PlaySound(sndSkill); // ����ޯ୵��
                    isSkillActive = true;
                    skillActiveTimer = 0.8f; 
                    skillsLeft--;
                }

                if (waitingForMismatch) {
                    mismatchTimer += dt;
                    if (mismatchTimer >= 0.5f) { 
                        firstSelectedR = firstSelectedC = -1;
                        secondSelectedR = secondSelectedC = -1;
                        waitingForMismatch = false;
                        mismatchTimer = 0.0f;
                    }
                }
                else if (!isSkillActive) {
                    int currentRows = LEVELS[currentLevel].rows;
                    int currentCols = LEVELS[currentLevel].cols;
                    
                    // �d�P�a���Y��
                    for (int r = 0; r < currentRows; r++) {
                        for (int c = 0; c < currentCols; c++) {
                            bool isHovered = CheckCollisionPointRec(mousePos, board[r][c].rect);
                            if (isHovered && !board[r][c].isRevealed) {
                                board[r][c].currentSizeScale += dt * 0.5f;
                                if (board[r][c].currentSizeScale > 1.06f) board[r][c].currentSizeScale = 1.06f;
                            } else {
                                board[r][c].currentSizeScale -= dt * 0.5f;
                                if (board[r][c].currentSizeScale < 1.0f) board[r][c].currentSizeScale = 1.0f;
                            }
                        }
                    }

                    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                        for (int r = 0; r < currentRows; r++) {
                            for (int c = 0; c < currentCols; c++) {
                                if (CheckCollisionPointRec(mousePos, board[r][c].rect) && !board[r][c].isRevealed) {
                                    if (r == firstSelectedR && c == firstSelectedC) continue;

                                    PlaySound(sndClick); // �C���I�P�����I������

                                    if (firstSelectedR == -1) {
                                        firstSelectedR = r; firstSelectedC = c;
                                    } else if (secondSelectedR == -1) {
                                        secondSelectedR = r; secondSelectedC = c;

                                        // �t�令�\�I
                                        if (board[firstSelectedR][firstSelectedC].value == board[secondSelectedR][secondSelectedC].value) {
                                            board[firstSelectedR][firstSelectedC].isRevealed = true;
                                            board[secondSelectedR][secondSelectedC].isRevealed = true;
                                            pairsFound++;
                                            combo++; 
                                            score += 100 * combo + (int)(gameTimer * 2); 

                                            PlaySound(sndMatch); // ���񦨥\����

                                            // --- �S��Ĳ�o�G�b�t�令�\����i�P�����z�o�ɤl ---
                                            Vector2 center1 = { board[firstSelectedR][firstSelectedC].rect.x + board[firstSelectedR][firstSelectedC].rect.width/2, board[firstSelectedR][firstSelectedC].rect.y + board[firstSelectedR][firstSelectedC].rect.height/2 };
                                            Vector2 center2 = { board[secondSelectedR][secondSelectedC].rect.x + board[secondSelectedR][secondSelectedC].rect.width/2, board[secondSelectedR][secondSelectedC].rect.y + board[secondSelectedR][secondSelectedC].rect.height/2 };
                                            TriggerParticles(particles, center1, COLOR_ACCENT);
                                            TriggerParticles(particles, center2, ORANGE);

                                            firstSelectedR = firstSelectedC = -1;
                                            secondSelectedR = secondSelectedC = -1;

                                            if (pairsFound == (currentRows * currentCols) / 2) {
                                                if (currentLevel < 2) {
                                                    currentLevel++;
                                                    InitializeLevel(currentLevel, board);
                                                    pairsFound = 0; combo = 0; skillsLeft = 2;
                                                    gameTimer = LEVELS[currentLevel].timeLimit;
                                                } else {
                                                    isVictory = true;
                                                    SaveHighScore(score);
                                                    currentState = STATE_END; 
                                                }
                                            }
                                        } else { // �t�異��
                                            if (combo > 0) combo--; 
                                            PlaySound(sndFail); // ���񥢱ѧC��
                                            waitingForMismatch = true;
                                            mismatchTimer = 0.0f;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                break;
            }

            case STATE_END: {
                if (IsKeyPressed(KEY_R)) {
                    PlaySound(sndClick);
                    currentState = STATE_TITLE;
                }
                break;
            }
        }

        // --- 2. �e��ø�s ---
        BeginDrawing();
        ClearBackground(COLOR_BG); 

        switch (currentState) {
            case STATE_TITLE: {
                DrawCircle(SCREEN_WIDTH / 2, 250, 220, Fade(COLOR_CARD_BACK, 0.2f));
                DrawCircle(SCREEN_WIDTH / 2, 250, 160, Fade(COLOR_BG, 1.0f));
                DrawText("CYBER", SCREEN_WIDTH / 2 - MeasureText("CYBER", 54) / 2 + 4, 154, 54, COLOR_SHADOW);
                DrawText("CYBER", SCREEN_WIDTH / 2 - MeasureText("CYBER", 54) / 2, 150, 54, COLOR_ACCENT);
                DrawText("MEMORY MATCH", SCREEN_WIDTH / 2 - MeasureText("MEMORY MATCH", 44) / 2 + 3, 223, 44, COLOR_SHADOW);
                DrawText("MEMORY MATCH", SCREEN_WIDTH / 2 - MeasureText("MEMORY MATCH", 44) / 2, 220, 44, COLOR_TEXT_LIGHT);
                DrawText("JUICED FX EDITION", SCREEN_WIDTH / 2 - MeasureText("JUICED FX EDITION", 16) / 2, 285, 16, GREEN);

                string hiScoreStr = "ALL-TIME HIGH SCORE: " + to_string(highScore);
                DrawRectangleRounded({ (float)SCREEN_WIDTH / 2 - 160, 340, 320, 35 }, 0.2f, 4, COLOR_CARD_BACK);
                DrawText(hiScoreStr.c_str(), SCREEN_WIDTH / 2 - MeasureText(hiScoreStr.c_str(), 14) / 2, 350, 14, GOLD);

                Rectangle startBtn = { (float)SCREEN_WIDTH / 2 - 125, 460, 250, 55 };
                bool isHoveringStart = CheckCollisionPointRec(mousePos, startBtn);
                DrawRectangleRounded(startBtn, 0.25f, 4, isHoveringStart ? COLOR_CARD_HOVER : COLOR_CARD_BACK);
                DrawRectangleRoundedLines(startBtn, 0.25f, 4, isHoveringStart ? WHITE : COLOR_ACCENT);
                DrawText("START GAME", startBtn.x + (startBtn.width - MeasureText("START GAME", 20)) / 2, startBtn.y + 18, 20, isHoveringStart ? WHITE : COLOR_TEXT_LIGHT);

                if (((int)(titleTextTimer * 2) % 2) == 0) {
                    DrawText("Press [ENTER] to Quick Start", SCREEN_WIDTH / 2 - MeasureText("Press [ENTER] to Quick Start", 15) / 2, 540, 15, GRAY);
                }

                Rectangle infoBox = { (float)SCREEN_WIDTH / 2 - 200, 600, 400, 120 };
                DrawRectangleRounded(infoBox, 0.1f, 4, Fade(COLOR_CARD_BACK, 0.4f));
                DrawRectangleRoundedLines(infoBox, 0.1f, 4, Fade(COLOR_ACCENT, 0.2f));
                DrawText("HOW TO PLAY", infoBox.x + 20, infoBox.y + 15, 14, COLOR_ACCENT);
                DrawText("- Left Click : Flip and match identical cards", infoBox.x + 20, infoBox.y + 42, 14, COLOR_TEXT_LIGHT);
                DrawText("- [SPACE]    : Activate X-Ray vision (2/level)", infoBox.x + 20, infoBox.y + 67, 14, GREEN);
                DrawText("- Audio Synthesizer: 100% Native Code 8-bit Sound", infoBox.x + 20, infoBox.y + 92, 14, GOLD);
                break;
            }

            case STATE_GAMEPLAY: {
                int currentRows = LEVELS[currentLevel].rows;
                int currentCols = LEVELS[currentLevel].cols;

                DrawText("CYBER MEMORY MATCH", 45, 25, 28, COLOR_TEXT_LIGHT);
                DrawText(("LEVEL: " + to_string(currentLevel + 1) + " / 3").c_str(), 45, 60, 16, COLOR_ACCENT);
                
                DrawRectangleRounded({ 45, 95, 140, 50 }, 0.2f, 4, COLOR_CARD_BACK);
                DrawText("SCORE", 60, 103, 11, COLOR_ACCENT);
                DrawText(to_string(score).c_str(), 60, 117, 20, COLOR_TEXT_LIGHT);

                DrawRectangleRounded({ 200, 95, 100, 50 }, 0.2f, 4, COLOR_CARD_BACK);
                DrawText("COMBO", 215, 103, 11, ORANGE);
                DrawText(("x" + to_string(combo)).c_str(), 215, 117, 20, combo > 0 ? ORANGE : COLOR_TEXT_LIGHT);

                DrawRectangleRounded({ 315, 95, 150, 50 }, 0.2f, 4, COLOR_CARD_BACK);
                DrawText("PROP: [SPACE]", 325, 103, 11, GREEN);
                DrawText((to_string(skillsLeft) + " SHOWS LEFT").c_str(), 325, 117, 16, skillsLeft > 0 ? GREEN : RED);

                DrawText("TIME LEFT", 485, 100, 12, COLOR_TEXT_LIGHT);
                DrawRectangle(485, 120, 215, 14, COLOR_CARD_BACK); 
                float timePercentage = gameTimer / LEVELS[currentLevel].timeLimit;
                float timeBarWidth = timePercentage * 215.0f;
                if (timeBarWidth < 0) timeBarWidth = 0;
                DrawRectangle(485, 120, (int)timeBarWidth, 14, timePercentage > 0.3f ? COLOR_ACCENT : RED);

                int fontSize = (currentRows == 6) ? 38 : 52;

                for (int r = 0; r < currentRows; r++) {
                    for (int c = 0; c < currentCols; c++) {
                        bool showFront = board[r][c].isRevealed || 
                                         (r == firstSelectedR && c == firstSelectedC) || 
                                         (r == secondSelectedR && c == secondSelectedC) ||
                                         isSkillActive;

                        bool isHovered = CheckCollisionPointRec(mousePos, board[r][c].rect);

                        Rectangle currentRect = board[r][c].rect;
                        if (!board[r][c].isRevealed) {
                            float widthDiff = currentRect.width * (board[r][c].currentSizeScale - 1.0f);
                            float heightDiff = currentRect.height * (board[r][c].currentSizeScale - 1.0f);
                            currentRect.x -= widthDiff / 2; currentRect.y -= heightDiff / 2;
                            currentRect.width += widthDiff; currentRect.height += heightDiff;
                        }

                        float textX = currentRect.x + (currentRect.width - MeasureText(showFront ? (char[]){board[r][c].value, '\0'} : "?", fontSize)) / 2;
                        float textY = currentRect.y + (currentRect.height - fontSize) / 2;

                        if (showFront) {
                            DrawRectangleRounded(currentRect, 0.15f, 4, COLOR_CARD_FRONT);
                            DrawRectangleRoundedLines(currentRect, 0.15f, 4, LIGHTGRAY);
                            char text[2] = { board[r][c].value, '\0' };
                            DrawText(text, textX, textY, fontSize, COLOR_TEXT_DARK); 
                        } else {
                            Rectangle shadowRect = { currentRect.x + 3, currentRect.y + 4, currentRect.width, currentRect.height };
                            DrawRectangleRounded(shadowRect, 0.15f, 4, COLOR_SHADOW);

                            Color currentBackColor = (isHovered && !waitingForMismatch) ? COLOR_CARD_HOVER : COLOR_CARD_BACK;
                            DrawRectangleRounded(currentRect, 0.15f, 4, currentBackColor);
                            DrawRectangleRoundedLines(currentRect, 0.15f, 4, (isHovered && !waitingForMismatch) ? COLOR_ACCENT : Fade(COLOR_ACCENT, 0.3f));
                            DrawText("?", textX, textY, fontSize, COLOR_ACCENT);
                        }
                    }
                }
                break;
            }

            case STATE_END: {
                DrawRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, Fade(COLOR_BG, 0.88f));
                if (isVictory) {
                    DrawText("GRAND VICTORY!!", SCREEN_WIDTH / 2 - 180, SCREEN_HEIGHT / 2 - 60, 46, GOLD);
                    DrawText(("FINAL SCORE: " + to_string(score)).c_str(), SCREEN_WIDTH / 2 - 100, SCREEN_HEIGHT / 2 + 10, 24, COLOR_TEXT_LIGHT);
                } else {
                    DrawText("GAME OVER", SCREEN_WIDTH / 2 - 120, SCREEN_HEIGHT / 2 - 60, 46, RED);
                }
                DrawText("Press [R] to Return to Title", SCREEN_WIDTH / 2 - 135, SCREEN_HEIGHT / 2 + 120, 18, GRAY);
                break;
            }
        }

        // --- �S��ø�s�G�b�̤W�h��V�ɤl�t�� ---
        for (const auto& p : particles) {
            DrawCircleV(p.position, p.size, Fade(p.color, p.alpha));
        }

        EndDrawing();
    }

    // �������İO����
    UnloadSound(sndClick);
    UnloadSound(sndMatch);
    UnloadSound(sndFail);
    UnloadSound(sndSkill);
    
    // --- �������T�˸m ---
    CloseAudioDevice();
    CloseWindow();
    return 0;
}
