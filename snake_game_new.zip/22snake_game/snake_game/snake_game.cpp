// main.cpp - �g��g�Y�D�C�� (�ʭ���ı���ƯS�Ī�)
// �sĶ���O: g++ main.cpp libraylib.a -o snake.exe -I. -L. -lopengl32 -lgdi32 -lwinmm -std=c++17 -static -mwindows
#include "raylib.h" 
#include <vector>
#include <deque>
#include <cstdlib>
#include <ctime>
#include <string>
#include <cmath> // �Ω� sin() �s�@�{�{�ʵe

// ============ �`�Ƴ]�w ============
constexpr int CELL_SIZE = 20;       
constexpr int GRID_WIDTH = 30;      
constexpr int GRID_HEIGHT = 25;     
constexpr int SCREEN_WIDTH = CELL_SIZE * GRID_WIDTH;
constexpr int SCREEN_HEIGHT = CELL_SIZE * GRID_HEIGHT + 40; 
constexpr float MOVE_INTERVAL = 0.16f; 

// ============ �C�����A�P�C�| ============
enum class Direction { UP, DOWN, LEFT, RIGHT };
enum class GameState { TITLE, GAMEPLAY }; 

struct Position {
    int x; int y;
    bool operator==(const Position& other) const { return x == other.x && y == other.y; }
};

// ============ Food ���O ============
class Food {
public:
    Position position;
    Color color;
    Food() : color(RED) { position = {0, 0}; }
    
    void spawn() {
        position.x = std::rand() % GRID_WIDTH;
        position.y = std::rand() % GRID_HEIGHT;
    }
    
    void draw() const {
        // ����ī�G�G�[�I���O���v�P
        DrawRectangle(position.x * CELL_SIZE, position.y * CELL_SIZE + 40, CELL_SIZE - 1, CELL_SIZE - 1, RED);
        DrawRectangle(position.x * CELL_SIZE + 3, position.y * CELL_SIZE + 43, 4, 4, MAROON); 
    }
};

// ============ Snake ���O ============
class Snake {
public:
    std::deque<Position> body;
    Direction direction;
    Direction nextDirection;
    bool alive;
    
    Snake() : direction(Direction::RIGHT), nextDirection(Direction::RIGHT), alive(true) {
        int startX = GRID_WIDTH / 2;
        int startY = GRID_HEIGHT / 2;
        body.push_front({startX, startY});
        body.push_back({startX - 1, startY});
        body.push_back({startX - 2, startY});     
    }
    
    void handleInput() {
        if (IsKeyPressed(KEY_UP) && direction != Direction::DOWN) nextDirection = Direction::UP;
        if (IsKeyPressed(KEY_DOWN) && direction != Direction::UP) nextDirection = Direction::DOWN;
        if (IsKeyPressed(KEY_LEFT) && direction != Direction::RIGHT) nextDirection = Direction::LEFT;
        if (IsKeyPressed(KEY_RIGHT) && direction != Direction::LEFT) nextDirection = Direction::RIGHT;
    }
    
    void move() {
        if (!alive) return;
        direction = nextDirection;
        Position newHead = body.front();
        switch (direction) {
            case Direction::UP:    newHead.y--; break;
            case Direction::DOWN:  newHead.y++; break;
            case Direction::LEFT:  newHead.x--; break;
            case Direction::RIGHT: newHead.x++; break;
        }
        body.push_front(newHead);
    }
    
    void removeTail() { body.pop_back(); }
    Position getHead() const { return body.front(); }
    
    bool checkWallCollision() const {
        Position head = getHead();
        return (head.x < 0 || head.x >= GRID_WIDTH || head.y < 0 || head.y >= GRID_HEIGHT);
    }
    
    bool checkSelfCollision() const {
        Position head = getHead();
        for (size_t i = 1; i < body.size(); ++i) {
            if (head == body[i]) return true;
        }
        return false;
    }
    
    void draw() const {
        for (size_t i = 0; i < body.size(); ++i) {
            Color sColor = (i == 0) ? DARKGREEN : GREEN;
            DrawRectangle(body[i].x * CELL_SIZE, body[i].y * CELL_SIZE + 40, CELL_SIZE - 2, CELL_SIZE - 2, sColor);
            // ���D�Y�[�W�@���i�R���p����
            if (i == 0) {
                DrawCircle(body[i].x * CELL_SIZE + 6, body[i].y * CELL_SIZE + 46, 2, WHITE);
                DrawCircle(body[i].x * CELL_SIZE + 14, body[i].y * CELL_SIZE + 46, 2, WHITE);
            }
        }
    }
};

// ============ �D�{�� ============
int main() {
    std::srand(static_cast<unsigned>(std::time(nullptr)));
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Snake Game - Deluxe Edition");
    InitAudioDevice();

    // ���J�귽
    Music bgm = LoadMusicStream("resources/bgm.mp3");
    Sound eatSound = LoadSound("resources/eat.mp3"); 
    Sound dieSound1 = LoadSound("resources/die1.mp3"); 
    Sound dieSound2 = LoadSound("resources/die2.mp3");

    float volume = 0.4f; 
    int foodCount = 5; 
    
    PlayMusicStream(bgm);
    SetTargetFPS(60);
    
    Snake snake;
    std::vector<Food> foods;
    
    int score = 0;
    float moveTimer = 0.0f;
    bool gameOver = false;
    bool isPaused = false; 
    
    GameState state = GameState::TITLE; 
    
    // �D�e������ UI �����s���
    Rectangle startBtn = { (float)SCREEN_WIDTH / 2 - 110, (float)SCREEN_HEIGHT / 2 - 10, 220, 55 };
    Rectangle minusBtn = { (float)SCREEN_WIDTH / 2 - 100, (float)SCREEN_HEIGHT / 2 + 110, 45, 35 };
    Rectangle plusBtn  = { (float)SCREEN_WIDTH / 2 + 55, (float)SCREEN_HEIGHT / 2 + 110, 45, 35 };
    
    while (!WindowShouldClose()) {
        UpdateMusicStream(bgm);
        float deltaTime = GetFrameTime();
        Vector2 mousePos = GetMousePosition(); 
        
        // ---- ���쭵�q�վ��޿� ----
        if (state == GameState::TITLE) {
            if (IsKeyPressed(KEY_UP) || IsKeyPressed(KEY_PAGE_UP)) volume += 0.1f;
            if (IsKeyPressed(KEY_DOWN) || IsKeyPressed(KEY_PAGE_DOWN)) volume -= 0.1f;
        } else {
            if (IsKeyPressed(KEY_PAGE_UP)) volume += 0.1f;
            if (IsKeyPressed(KEY_PAGE_DOWN)) volume -= 0.1f;
        }
        
        if (volume > 1.0f) volume = 1.0f;
        if (volume < 0.0f) volume = 0.0f;
        
        SetMusicVolume(bgm, volume);
        SetSoundVolume(eatSound, volume);
        SetSoundVolume(dieSound1, volume);
        SetSoundVolume(dieSound2, volume);
        
        // ---- �֤ߪ��A�޿���� ----
        switch (state) {
            case GameState::TITLE: {
                if ((CheckCollisionPointRec(mousePos, startBtn) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) || IsKeyPressed(KEY_ENTER)) {
                    foods.resize(foodCount);
                    for (auto& f : foods) f.spawn();
                    snake = Snake();
                    score = 0;
                    moveTimer = 0.0f;
                    gameOver = false;
                    isPaused = false;
                    PlayMusicStream(bgm);
                    state = GameState::GAMEPLAY;
                }
                
                if (CheckCollisionPointRec(mousePos, minusBtn) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                    if (foodCount > 1) foodCount--;
                }
                
                if (CheckCollisionPointRec(mousePos, plusBtn) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                    if (foodCount < 10) foodCount++;
                }
                break;
            }
            case GameState::GAMEPLAY: {
                if (!gameOver) {
                    if (IsKeyPressed(KEY_P)) {
                        isPaused = !isPaused;
                        if (isPaused) PauseMusicStream(bgm);
                        else ResumeMusicStream(bgm);
                    }

                    if (!isPaused) {
                        snake.handleInput();
                        moveTimer += deltaTime;
                        
                        if (moveTimer >= MOVE_INTERVAL) {
                            moveTimer = 0.0f;
                            snake.move();
                            
                            if (snake.checkWallCollision() || snake.checkSelfCollision()) {
                                snake.alive = false;
                                gameOver = true;
                                StopMusicStream(bgm);
                                
                                if (score >= 200) PlaySound(dieSound1); 
                                else PlaySound(dieSound2);
                            } else {
                                bool ate = false;
                                for (auto& f : foods) {
                                    if (snake.getHead() == f.position) {
                                        score += 10;
                                        f.spawn();
                                        PlaySound(eatSound);
                                        ate = true;
                                        break;
                                    }
                                }
                                if (!ate) snake.removeTail();
                            }
                        }
                    }
                } else {
                    if (IsKeyPressed(KEY_R)) {
                        StopSound(dieSound1); StopSound(dieSound2);
                        snake = Snake();
                        for (auto& f : foods) f.spawn();
                        score = 0;
                        moveTimer = 0.0f;
                        gameOver = false;
                        isPaused = false;
                        PlayMusicStream(bgm);
                    }
                    if (IsKeyPressed(KEY_M)) {
                        StopSound(dieSound1); StopSound(dieSound2);
                        state = GameState::TITLE; 
                    }
                }
                break;
            }
        }
        
        // ---- ø�s�e�� ----
        BeginDrawing();
        ClearBackground(WHITE);
        
        if (state == GameState::TITLE) {
            // ====== ø�s����P�ʭ� ======
            // 1. ����אּ��`�㪺���ȶ�
            DrawRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, GetColor(0x111116FF));
            
            // 2. ø�s��ޭ���ޭI������u
            for (int i = 0; i < SCREEN_WIDTH; i += CELL_SIZE * 2) {
                DrawLine(i, 0, i, SCREEN_HEIGHT, GetColor(0x1F1F2EFF));
            }
            for (int i = 0; i < SCREEN_HEIGHT; i += CELL_SIZE * 2) {
                DrawLine(0, i, SCREEN_WIDTH, i, GetColor(0x1F1F2EFF));
            }
            
            // 3. �p��ʺA�{�{/�I�l�O�j�� (�B�� Sin �i���)
            float pulse = (std::sin(GetTime() * 4.0f) + 1.0f) / 2.0f; // 0.0f �� 1.0f
            Color blinkLime = Fade(LIME, 0.6f + pulse * 0.4f);
            
            // 4. ø�s�j���D (�t�Ŭ����鳱�v)
            const char* titleText = "SNAKE GAME";
            int titleWidth = MeasureText(titleText, 55);
            int titleX = (SCREEN_WIDTH - titleWidth) / 2;
            int titleY = SCREEN_HEIGHT / 2 - 110;
            
            DrawText(titleText, titleX + 4, titleY + 4, 55, BLACK);     // �¦⳱�v�h
            DrawText(titleText, titleX, titleY, 55, GetColor(0x20B2AAFF)); // �D��G�ﻫ�ź��
            
            // 5. START ���ʫ��s (��Υ~�o����޷P�]�p)
            bool hoverStart = CheckCollisionPointRec(mousePos, startBtn);
            
            // ø�s���s����
            DrawRectangleRec(startBtn, hoverStart ? GetColor(0x00A36CFF) : GetColor(0x0B6623FF)); 
            // �a���ɼW�[�ծإ~�o��
            DrawRectangleLinesEx(startBtn, hoverStart ? 3 : 1, hoverStart ? LIME : WHITE);
            
            // ���s����r�[�W�ʺA�I�l�G��
            DrawText("START GAME", startBtn.x + (startBtn.width - MeasureText("START GAME", 22)) / 2, startBtn.y + 16, 22, hoverStart ? blinkLime : WHITE);
            
            // 6. ī�G�ƶq�վ� UI �϶�����
            DrawText("APPLES QUANTITY", SCREEN_WIDTH / 2 - 110, SCREEN_HEIGHT / 2 + 75, 18, LIGHTGRAY);
            
            // ��֫��s [-]
            bool hoverMinus = CheckCollisionPointRec(mousePos, minusBtn);
            DrawRectangleRec(minusBtn, hoverMinus ? GetColor(0x555566FF) : GetColor(0x333344FF));
            DrawRectangleLines(minusBtn.x, minusBtn.y, minusBtn.width, minusBtn.height, GRAY);
            DrawText("-", minusBtn.x + 18, minusBtn.y + 6, 22, WHITE);
            
            // ��ܷ��e�ƶq�Ʀr (�ʺA�{�{����)
            DrawText(TextFormat("%02d", foodCount), SCREEN_WIDTH / 2 - 13, SCREEN_HEIGHT / 2 + 114, 26, blinkLime);
            
            // �W�[���s [+]
            bool hoverPlus = CheckCollisionPointRec(mousePos, plusBtn);
            DrawRectangleRec(plusBtn, hoverPlus ? GetColor(0x555566FF) : GetColor(0x333344FF));
            DrawRectangleLines(plusBtn.x, plusBtn.y, plusBtn.width, plusBtn.height, GRAY);
            DrawText("+", plusBtn.x + 16, plusBtn.y + 6, 22, WHITE);
            
            // 7. �������������U�ާ@����
            DrawText(TextFormat("BGM Volume: %d%%", static_cast<int>(volume * 100)), (SCREEN_WIDTH - MeasureText("BGM Volume: 100%", 16)) / 2, SCREEN_HEIGHT / 2 + 175, 16, LIGHTGRAY);
            
            DrawRectangle(20, SCREEN_HEIGHT - 65, SCREEN_WIDTH - 40, 1, GetColor(0x333344FF)); // ���νu
            DrawText("Controls: Arrow Keys to turn snake | P to Pause game", 35, SCREEN_HEIGHT - 50, 15, GRAY);
            DrawText("Volume adjustment: Keyboard [Page Up] / [Page Down]", 35, SCREEN_HEIGHT - 30, 15, GRAY);
            
        } else if (state == GameState::GAMEPLAY) {
            // ====== ø�s�C���e�� ======
            DrawRectangle(0, 0, SCREEN_WIDTH, 40, LIGHTGRAY);
            DrawText(TextFormat("Score: %d", score), 10, 10, 24, DARKGRAY);
            DrawText(TextFormat("Vol: %d%%", static_cast<int>(volume * 100)), SCREEN_WIDTH - 120, 12, 20, DARKGRAY);
            
            DrawRectangleLines(0, 40, SCREEN_WIDTH, SCREEN_HEIGHT - 40, DARKGRAY);
            
            for (const auto& f : foods) f.draw();
            snake.draw();
            
            if (isPaused && !gameOver) {
                DrawRectangle(0, 40, SCREEN_WIDTH, SCREEN_HEIGHT - 40, Fade(BLACK, 0.5f));
                DrawText("PAUSED", (SCREEN_WIDTH - MeasureText("PAUSED", 40)) / 2, SCREEN_HEIGHT / 2 - 20, 40, WHITE);
                DrawText("Press P to Resume", (SCREEN_WIDTH - MeasureText("Press P to Resume", 16)) / 2, SCREEN_HEIGHT / 2 + 30, 16, LIGHTGRAY);
            }
            
            if (gameOver) {
                DrawRectangle(0, 40, SCREEN_WIDTH, SCREEN_HEIGHT - 40, Fade(BLACK, 0.7f));
                DrawText("GAME OVER", (SCREEN_WIDTH - MeasureText("GAME OVER", 40)) / 2, SCREEN_HEIGHT / 2 - 50, 40, RED);
                DrawText("Press [R] to Retry", (SCREEN_WIDTH - MeasureText("Press [R] to Retry", 20)) / 2, SCREEN_HEIGHT / 2 + 10, 20, WHITE);
                DrawText("Press [M] for Main Menu", (SCREEN_WIDTH - MeasureText("Press [M] for Main Menu", 20)) / 2, SCREEN_HEIGHT / 2 + 45, 20, LIME);
            }
        }
        
        EndDrawing();
    }
    
    // --- ����귽 ---
    UnloadMusicStream(bgm);
    UnloadSound(eatSound);
    UnloadSound(dieSound1);
    UnloadSound(dieSound2);
    CloseAudioDevice();
    CloseWindow();
    
    return 0;
}
